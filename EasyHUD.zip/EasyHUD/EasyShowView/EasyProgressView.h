





#import <UIKit/UIKit.h>


@interface EasyProgressView : UIView

/**
 下载进度,内部按1.0计算
 */
@property (nonatomic, assign) CGFloat progress;
/**
 宽度 默认10
 */
@property (nonatomic, assign) CGFloat progressWidth;

/** 进度条View背景颜色 */
@property(nonatomic,strong) UIColor *progressViewBgColor;
/** 进度条颜色 */
@property(nonatomic,strong) UIColor *progressBarColor;


+ (instancetype)sharedSingletonView;

+ (void)showHUDWithTitle:(NSString *)title progress:(CGFloat)progress inView:(UIView *)parentView;

+ (void)hideWaitView;


@end
