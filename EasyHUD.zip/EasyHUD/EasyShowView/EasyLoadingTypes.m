//
//  EasyLoadingTypes.m
//  EasyShowViewDemo
//
//  Created by nf on 2018/3/13.
//  Copyright © 2018年 chenliangloveyou. All rights reserved.
//

#import "EasyLoadingTypes.h"


const CGFloat EasyShowLoadingMaxWidth = 200 ;    //显示文字的最大宽度（高度已限制死）
const CGFloat EasyShowLoadingImageEdge = 10 ;    //加载框图片的边距
const CGFloat EasyShowLoadingImageWH = 30 ;      //加载框图片的大小
const CGFloat EasyShowLoadingImageMaxWH = 60 ;   //加载框图片的最大宽度

@implementation EasyLoadingTypes

@end
