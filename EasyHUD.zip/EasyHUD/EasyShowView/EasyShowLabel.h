//
//  EasyShowLabel.h
//  EasyShowViewDemo
//
//  Created by nf on 2017/12/20.
//  Copyright © 2017年 chenliangloveyou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EasyShowLabel : UILabel

- (instancetype)initWithContentInset:(UIEdgeInsets)contentInset ;

@end
