






#import "EasyProgressView.h"

#define Kwidth  [UIScreen mainScreen].bounds.size.width
#define Kheight  [UIScreen mainScreen].bounds.size.height
#define HUDColorAlpha(r, g, b, a)     [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:(a)]
#define HUDColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]



/** 文字顶部底部间距 */
#define KMargin 15

#define KProgressBorderWidth 2.0f
#define KProgressPadding 1.0f


@interface EasyProgressView()


/** 百分百文字 */
@property (nonatomic, strong) UILabel *percentTextLabel;
/** 提示文字 */
@property (nonatomic, strong) UILabel *TextLabel;


@end


@implementation EasyProgressView

static EasyProgressView *viewObject = nil;



- (void)setProgress:(CGFloat)progress
{
    _progress = progress;

    self.percentTextLabel.text = [NSString stringWithFormat:@"%d%%", (int)floor(progress * 100)];

    
    if (_progress >= 1.0) {
        [self removeFromSuperview];

        
    } else {
        [self setNeedsDisplay];
    }
    
}

-(void)setProgressWidth:(CGFloat)progressWidth{
    
    _progressWidth = progressWidth;
    [self setNeedsDisplay];
 
}

-(void)setProgressViewBgColor:(UIColor *)progressViewBgColor{
    _progressViewBgColor = progressViewBgColor;
}
-(void)setProgressBarColor:(UIColor *)progressBarColor{
    _progressBarColor = progressBarColor;
}

- (void)drawRect:(CGRect)rect
{
    
    [self Style_percentAndText:rect];
    
}



#pragma mark - 百分百和文字 (默认)
-(void)Style_percentAndText:(CGRect)rect{
    
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGFloat xCenter = rect.size.width * 0.5;
    CGFloat yCenter = rect.size.height * 0.25 + KMargin;

    [_progressBarColor set];

    //设置圆环的宽度
    CGContextSetLineWidth(ctx, _progressWidth);
    CGContextSetLineCap(ctx, kCGLineCapRound);
    CGFloat to = - M_PI * 0.5 + self.progress * M_PI * 2 + 0.05; // 初始值0.05
    //半径
    CGFloat radius = MIN(rect.size.width, rect.size.height) * 0.3 - KMargin;
    CGContextAddArc(ctx, xCenter, yCenter, radius, - M_PI * 0.5, to, 0);
    CGContextStrokePath(ctx);

    CGFloat FrameWidth = self.bounds.size.width;
    self.percentTextLabel.frame = CGRectMake(0, yCenter-10, FrameWidth, 20);
    
}



- (void)dismiss
{
   self.progress = 1.0;
}


+ (instancetype)sharedSingletonView{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        viewObject = [[super allocWithZone:NULL] init];
    });
    
    return viewObject;
}

+ (void)showHUDWithTitle:(NSString *)title progress:(CGFloat)progress inView:(UIView *)parentView{
    
    EasyProgressView *obj = [EasyProgressView sharedSingletonView];
    
    NSLog(@"%p",obj);//都是同一个地址
    
    [obj showHUDWithTitle:title progress:progress inView:parentView];
}

+ (void)hideWaitView{
    [viewObject removeFromSuperview];
}

+ (instancetype)alloc{
    
    
    return [EasyProgressView sharedSingletonView];
}

+(instancetype)allocWithZone:(struct _NSZone *)zone{
    
    return [EasyProgressView sharedSingletonView];
}

#pragma mark - override

- (instancetype)initWithFrame:(CGRect)frame
{
    
    if (self = [super initWithFrame:frame]) {
        
        self = [self customInitMethod];
        
    }
    
    return self;
}

//初始化
- (instancetype)customInitMethod{
    
    self.layer.cornerRadius = 5;
    self.clipsToBounds = YES;
    
    self.progressBarColor = [UIColor whiteColor];
    self.progressViewBgColor = HUDColor(45, 45, 45);
    self.backgroundColor =_progressViewBgColor;
    
    self.progressWidth = 5;
    
    _percentTextLabel = [[UILabel alloc]init];
    _percentTextLabel.text = @"0%";
    _percentTextLabel.textColor = _progressBarColor;
    _percentTextLabel.font = [UIFont systemFontOfSize:13];
    _percentTextLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.percentTextLabel];
    
    _TextLabel = [[UILabel alloc] init];
    _TextLabel.textColor = _progressBarColor;
    _TextLabel.font = [UIFont systemFontOfSize:14];
    _TextLabel.textAlignment = NSTextAlignmentCenter;
    
    
    [self addSubview:self.TextLabel];
    
    return self;
}



- (void)showHUDWithTitle:(NSString *)title progress:(CGFloat)progress inView:(UIView *)parentView{
    
    
    CGFloat width = 120;
    CGFloat height = 120;
    CGRect frame = CGRectMake((Kwidth-width)/2,(Kheight-height)/2, width, height);
    viewObject.frame = frame;

    
     _percentTextLabel.frame = viewObject.bounds;
    
    CGFloat textHeight = 25;
    CGFloat FrameWidth = viewObject.bounds.size.width;
    CGFloat FrameHeight = viewObject.bounds.size.height;
    _TextLabel.frame = CGRectMake(0,FrameHeight-textHeight-KMargin, FrameWidth, textHeight);
    
    _TextLabel.text = title;
    
    self.progress = progress;
    
    [parentView addSubview:viewObject];
    
    
    [[self class] performSelector:@selector(hideWaitView) withObject:nil afterDelay:2];//如果要在外部调用hideWaitView方法，需将此处注释
    
}


@end
