





#import "EasyHUD.h"
#import "EasyShowView.h"

@implementation EasyHUD

+(void)showText:(NSString *)text{
    
    [EasyTextView showText:text config:^EasyTextConfig *{

        EasyTextConfig *config = [EasyTextConfig shared];
        config.bgColor = [UIColor colorWithWhite:0 alpha:0.8];
        config.titleColor = [UIColor whiteColor];
        config.shadowColor = [UIColor clearColor] ;
        config.animationType = TextAnimationTypeBounce;
        config.statusType = TextStatusTypeMidden ;
        return config ;
    }];
    
}

+(void)showSuccessText:(NSString *)text{
    
    [EasyTextView showSuccessText:text config:^EasyTextConfig *{
       
        EasyTextConfig *config = [EasyTextConfig shared];
        config.bgColor = [UIColor colorWithWhite:0 alpha:0.8];
        config.titleColor = [UIColor whiteColor];
        config.shadowColor = [UIColor clearColor] ;
        config.animationType = TextAnimationTypeBounce;
        config.statusType = TextStatusTypeMidden ;
        return config ;
        
    }];
    
    
}

+(void)showErrorText:(NSString *)text{
    
    [EasyTextView showErrorText:text config:^EasyTextConfig *{
        
        EasyTextConfig *config = [EasyTextConfig shared];
        config.bgColor = [UIColor colorWithWhite:0 alpha:0.8];
        config.titleColor = [UIColor whiteColor];
        config.shadowColor = [UIColor clearColor] ;
        config.animationType = TextAnimationTypeBounce;
        config.statusType = TextStatusTypeMidden ;
        return config ;

    }];
    
    
}

+(void)showInfoText:(NSString *)text{
    
    [EasyTextView showInfoText:text config:^EasyTextConfig *{
        
        EasyTextConfig *config = [EasyTextConfig shared];
        config.bgColor = [UIColor colorWithWhite:0 alpha:0.8];
        config.titleColor = [UIColor whiteColor];
        config.shadowColor = [UIColor clearColor] ;
        config.animationType = TextAnimationTypeBounce;
        config.statusType = TextStatusTypeMidden ;
        return config ;
        
    }];
}

+(void)showLoadingText:(NSString *)text{
    
    [EasyLoadingView showLoadingText:text config:^EasyLoadingConfig *{
        
        EasyLoadingConfig *config = [EasyLoadingConfig shared];
        config.LoadingType = LoadingShowTypeTurnAroundLeft;
        config.animationType = TextAnimationTypeFade;
        config.bgColor = [UIColor clearColor];
        config.superReceiveEvent = NO;
        return config;
    }];
    
    
    
}

+(void)hide{
    
    [EasyLoadingView hidenLoading];
}


+(void)showNoDataEmptyInView:(UIView *)superView callBack:(ReloadBlock)callBack{
    
    [EasyEmptyView showEmptyInView:superView part:^EasyEmptyPart *{
        return [EasyEmptyPart shared].setImageName(@"无数据.png").setSubtitle(@"数据加载失败，点击重新加载！").setButtonArray(@[@"点击重试"]);
    } config:nil callback:^(EasyEmptyView *view, UIButton *button, callbackType callbackType) {
        callBack();
    }];
    
}

+(void)showNoNetEmptyInView:(UIView *)superView callBack:(ReloadBlock)callBack{
    
    [EasyEmptyView showEmptyInView:superView part:^EasyEmptyPart *{
        return [EasyEmptyPart shared].setImageName(@"无网络.png").setSubtitle(@"网络连接失败！").setButtonArray(@[@"点击重试"]);
    } config:nil callback:^(EasyEmptyView *view, UIButton *button, callbackType callbackType) {
        callBack();
    }];
    
}

/** 显示进度 自动隐藏 */
+(void)showProgressText:(NSString *)text progress:(CGFloat)progress{
    
    [EasyProgressView showHUDWithTitle:text progress:progress inView:[UIApplication sharedApplication].keyWindow];
    
}

@end
