







#import <UIKit/UIKit.h>

typedef void(^ReloadBlock)(void);


@interface EasyHUD : NSObject


/** 显示提示文字 自动隐藏 */
+(void)showText:(NSString *)text;

/** 成功提示文字 自动隐藏 */
+(void)showSuccessText:(NSString *)text;

/** 失败提示文字 自动隐藏 */
+(void)showErrorText:(NSString *)text;

/** 提示文字 自动隐藏 */
+(void)showInfoText:(NSString *)text;

/** 加载中,text可以为nil 手动隐藏*/
+(void)showLoadingText:(NSString *)text;

/** 显示进度 自动隐藏 */
+(void)showProgressText:(NSString *)text progress:(CGFloat)progress;


/** 隐藏 */
+(void)hide;

/** 没有数据 空view */
+(void)showNoDataEmptyInView:(UIView *)superView callBack:(ReloadBlock)callBack;

/** 没有网络 空view */
+(void)showNoNetEmptyInView:(UIView *)superView callBack:(ReloadBlock)callBack;

@end

